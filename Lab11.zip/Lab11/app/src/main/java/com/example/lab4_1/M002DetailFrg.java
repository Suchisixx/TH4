package com.example.lab4_1;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class M002DetailFrg extends Fragment {

    private Context mContext;
    // Các biến dữ liệu
    private String name;
    private String imageFileName;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m002_act_detail, container, false);
        initViews(view);
        return view;
    }

    // Hàm nhận dữ liệu từ MainActivity
    public void setData(String name, String content, String imageFileName) {
        this.name = name;
        this.imageFileName = imageFileName;
    }

    private void initViews(View v) {
        ImageView ivDetail = v.findViewById(R.id.iv_detail_icon);
        TextView tvName = v.findViewById(R.id.tv_detail_name);
        TextView tvContent = v.findViewById(R.id.tv_detail_content);
        Button btnBack = v.findViewById(R.id.btn_back);

        tvName.setText(name);

        if (imageFileName != null) {
            // Load ảnh
            try (InputStream ims = mContext.getAssets().open("photo/" + imageFileName)) {
                Drawable d = Drawable.createFromStream(ims, null);
                ivDetail.setImageDrawable(d);
            } catch (IOException e) {
                e.printStackTrace();
            }
            // Load truyện full từ folder "story"
            loadStoryContent(imageFileName, tvContent);
        }

        btnBack.setOnClickListener(v1 -> {
            // Quay về
            ((MainActivity) getActivity()).backToMenu();
        });
    }

    private void loadStoryContent(String imageFileName, TextView tvContent) {
        String baseName = imageFileName;
        if (baseName.contains(".")) {
            baseName = baseName.substring(0, baseName.lastIndexOf('.'));
        }
        String storyPath = "story/" + baseName + ".txt";

        try {
            InputStream is = mContext.getAssets().open(storyPath);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            reader.readLine(); // Bỏ dòng tiêu đề
            StringBuilder contentBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                contentBuilder.append(line).append("\n");
            }
            tvContent.setText(contentBuilder.toString());
            reader.close();
        } catch (IOException e) {
            tvContent.setText("Không tìm thấy nội dung chi tiết.");
        }
    }
}