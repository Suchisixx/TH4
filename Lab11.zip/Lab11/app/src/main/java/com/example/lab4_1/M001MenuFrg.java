package com.example.lab4_1;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class M001MenuFrg extends Fragment {

    private Context mContext;
    private ConstraintLayout mainLayout;
    private ImageView ivSelected;
    private TextView tvNameSelected, tvDescShort;
    private Button btnSeeMore;

    private String currentTitle = "";
    private String currentImageFileName = "";

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Gắn layout của fragment
        View view = inflater.inflate(R.layout.m001_act_menu, container, false);
        initViews(view);
        renderPhotosFromAssets();
        return view;
    }

    private void initViews(View v) {
        mainLayout = v.findViewById(R.id.main_layout);
        ivSelected = v.findViewById(R.id.iv_icon_selected);
        tvNameSelected = v.findViewById(R.id.tv_name_selected);
        tvDescShort = v.findViewById(R.id.tv_desc_short);
        btnSeeMore = v.findViewById(R.id.btn_see_more);

        btnSeeMore.setOnClickListener(v1 -> {
            if (currentTitle.isEmpty()) {
                Toast.makeText(mContext, "Vui lòng chọn một cung hoàng đạo!", Toast.LENGTH_SHORT).show();
                return;
            }
            // Gọi hàm chuyển trang của MainActivity
            ((MainActivity) getActivity()).gotoM002Screen(currentTitle, null, currentImageFileName);
        });
    }

    private void renderPhotosFromAssets() {
        try {
            String[] files = mContext.getAssets().list("photo");
            if (files == null || files.length == 0) return;

            int numberOfPhotos = files.length;
            float angleStep = 360f / numberOfPhotos;
            int radiusInPx = dpToPx(130);
            int iconSizeInPx = dpToPx(50);

            for (int i = 0; i < numberOfPhotos; i++) {
                String fileName = files[i];

                ImageView imageView = new ImageView(mContext);
                imageView.setId(View.generateViewId());

                try (InputStream ims = mContext.getAssets().open("photo/" + fileName)) {
                    Drawable d = Drawable.createFromStream(ims, null);
                    imageView.setImageDrawable(d);
                }

                ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(iconSizeInPx, iconSizeInPx);
                params.circleConstraint = R.id.view_center;
                params.circleRadius = radiusInPx;
                params.circleAngle = angleStep * i;
                imageView.setLayoutParams(params);

                imageView.setOnClickListener(v -> loadInfoFromMoTaNgan(fileName));

                mainLayout.addView(imageView);

                if (i == 0) loadInfoFromMoTaNgan(fileName);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadInfoFromMoTaNgan(String imageFileName) {
        try (InputStream ims = mContext.getAssets().open("photo/" + imageFileName)) {
            Drawable d = Drawable.createFromStream(ims, null);
            ivSelected.setImageDrawable(d);
            currentImageFileName = imageFileName;
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseName = imageFileName;
        if (baseName.contains(".")) {
            baseName = baseName.substring(0, baseName.lastIndexOf('.'));
        }

        // Đọc từ motangan
        String textFileName = "motangan/" + baseName + ".txt";

        try {
            InputStream is = mContext.getAssets().open(textFileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            String title = reader.readLine();
            StringBuilder contentBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                contentBuilder.append(line).append("\n");
            }
            tvNameSelected.setText(title);
            tvDescShort.setText(contentBuilder.toString());
            currentTitle = title;
            reader.close();
        } catch (IOException e) {
            tvNameSelected.setText(baseName);
            tvDescShort.setText("Chưa có mô tả.");
            currentTitle = baseName;
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}