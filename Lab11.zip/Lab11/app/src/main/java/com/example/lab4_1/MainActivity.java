package com.example.lab4_1;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Mở màn hình Splash đầu tiên
        showFrg(new M000SplashFrg());
    }

    // Hàm hiển thị Fragment
    private void showFrg(Fragment frg) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, frg, null) // Đảm bảo ID layout là container_main
                .addToBackStack(null) // Cho phép bấm nút Back để quay lại
                .commit();
    }

    // Chuyển sang màn hình Menu (M001)
    public void gotoM001Screen() {
        // Xóa backstack để không back về splash được
        getSupportFragmentManager().popBackStack(null, androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE);
        showFrg(new M001MenuFrg());
    }

    // Chuyển sang màn hình Chi tiết (M002)
    public void gotoM002Screen(String name, String content, String imageFile) {
        M002DetailFrg frg = new M002DetailFrg();
        frg.setData(name, content, imageFile); // Truyền dữ liệu
        showFrg(frg);
    }

    // Quay lại màn hình Menu
    public void backToMenu() {
        getSupportFragmentManager().popBackStack();
    }
}