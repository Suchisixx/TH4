package com.example.lab3_b1_btth;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Tránh add lại M000 khi xoay màn hình
        if (savedInstanceState == null) {
            showFrg(new M000SplashFrg(), false); // Màn hình đầu tiên, không add vào back stack
        }
    }

    /**
     * Hàm hiển thị Fragment
     * @param frg Fragment để hiển thị
     * @param addToBackStack true nếu muốn bấm nút Back quay lại được
     */
    private void showFrg(Fragment frg, boolean addToBackStack) {
        var transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.main, frg);
        if (addToBackStack) {
            transaction.addToBackStack(null);
        }
        transaction.commit();
    }

    /** Màn hình chào gọi hàm này để vào Màn hình 1 */
    public void gotoM001Screen() {
        showFrg(new M001TopicFrg(), false); // Màn hình chính, không cần back lại M000
    }

    /** Màn hình 1 gọi hàm này để vào Màn hình 2 */
    public void gotoM002Screen(String topicName) {
        showFrg(M002StoryListFrg.newInstance(topicName), true);
    }

    /** Màn hình 2 gọi hàm này để vào Màn hình 3 */
    public void gotoM003Screen(String topicName, String storyTitle, String storyContent) {
        showFrg(M003StoryDetailFrg.newInstance(topicName, storyTitle, storyContent), true);
    }
}