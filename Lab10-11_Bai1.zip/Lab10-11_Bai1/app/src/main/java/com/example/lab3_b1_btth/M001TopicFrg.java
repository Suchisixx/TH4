package com.example.lab3_b1_btth;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

public class M001TopicFrg extends Fragment implements View.OnClickListener {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m001_frg_topic, container, false);

        // Tìm cả 3 View
        View itemPhongHoc = view.findViewById(R.id.item_phong_hoc);
        View itemHanhLang = view.findViewById(R.id.item_hanh_lang);
        View itemPhongThiNghiem = view.findViewById(R.id.item_phong_thi_nghiem);

        // Gán sự kiện click
        if (itemPhongHoc != null) itemPhongHoc.setOnClickListener(this);
        if (itemHanhLang != null) itemHanhLang.setOnClickListener(this);
        if (itemPhongThiNghiem != null) itemPhongThiNghiem.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {
        if (getActivity() == null) return;

        // Dùng ID để phân biệt và gửi TÊN CHỦ ĐỀ KINH DỊ mới
        int id = v.getId();
        String topicToSend = "";

        if (id == R.id.item_phong_hoc) {
            topicToSend = "Phòng Học Tử Thần";
        } else if (id == R.id.item_hanh_lang) {
            topicToSend = "Hành Lang Bóng Đêm";
        } else if (id == R.id.item_phong_thi_nghiem) {
            topicToSend = "Phòng Thí Nghiệm Cũ";
        }

        if (!topicToSend.isEmpty()) {
            ((MainActivity) getActivity()).gotoM002Screen(topicToSend);
        }
    }
}