package com.example.lab3_b1_btth;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class M002StoryListFrg extends Fragment {

    private String topicName;
    private LinearLayout storyListContainer;
    private LayoutInflater inflater;

    public static M002StoryListFrg newInstance(String topicName) {
        M002StoryListFrg fragment = new M002StoryListFrg();
        Bundle args = new Bundle();
        args.putString("TOPIC_NAME", topicName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.inflater = inflater; // Lưu lại inflater để dùng
        View view = inflater.inflate(R.layout.m002_frg_story_list, container, false);

        if (getArguments() != null) {
            topicName = getArguments().getString("TOPIC_NAME");
        }

        // --- Ánh xạ View ---
        TextView tvTopicName = view.findViewById(R.id.tv_topic_name_m002);
        ImageView ivBack = view.findViewById(R.id.iv_back_m002);
        storyListContainer = view.findViewById(R.id.story_list_container); // "Thùng chứa" rỗng

        // --- Gán dữ liệu ---
        tvTopicName.setText(topicName);

        // --- Bắt sự kiện click ---
        ivBack.setOnClickListener(v -> {
            if (getActivity() != null) {
                // Sử dụng phương thức backToM001Screen nếu nó có trong MainActivity
                // Nếu không, giữ nguyên dispatchers:
                getActivity().getOnBackPressedDispatcher().onBackPressed();
            }
        });

        // Tải các truyện dựa trên tên chủ đề
        loadStories();

        return view;
    }

    /**
     * Tự động thêm truyện dựa trên topicName
     * ĐÃ SỬA: Thay thế truyện cười bằng truyện kinh dị.
     */
    private void loadStories() {
        storyListContainer.removeAllViews(); // Xóa hết truyện cũ (nếu có)

        if (topicName.equals("Phòng Học Tử Thần")) {
            addStoryItem("Vị Trí Của Bạn", "Tôi là một học sinh cũ của THPT Võ Thị Sáu ở Quận Bình Thạnh, TPHCM. Vào một buổi tự học tối muộn, phòng học im lặng đến đáng sợ. Tôi ngồi ở bàn cuối, cảm giác như có ai đó đang nhìn chằm chằm vào gáy mình. Quay đầu lại, tôi thấy một bóng dáng mờ ảo ngồi ở vị trí mà mọi người đồn là 'ghế tử thần'. Đó là nơi một nữ sinh đã tự tử cách đây 10 năm. Bóng dáng ấy chậm rãi quay mặt về phía tôi, đôi mắt đen ngòm không đồng tử, miệng thì thầm: 'Đây là chỗ của tao... mày ngồi nhầm rồi.' Tôi chạy khỏi phòng, nhưng từ đó, mỗi đêm tôi đều mơ thấy mình bị kéo về chiếc ghế ấy, và lần nào cũng tỉnh dậy với những vết bầm tím trên tay.");
            addStoryItem("Bản Kiểm Điểm Máu", "Tôi từng là giáo viên chủ nhiệm ở THPT Võ Thị Sáu. Một hôm, khi dọn dẹp ngăn tủ cũ, tôi tìm thấy một bản kiểm điểm viết bằng mực đỏ như máu. Nội dung kể về lỗi lầm của một học sinh đã mất tích từ lâu. Mỗi lần tôi đọc một dòng, da thịt tôi như bị kim châm, và một vết cắt nông xuất hiện trên cánh tay. Đến dòng cuối cùng, 'Tôi sẽ không bao giờ tha thứ', tôi nghe tiếng cười khúc khích từ góc phòng tối. Từ đó, bản kiểm điểm ấy xuất hiện trong giấc mơ của tôi, và mỗi sáng thức dậy, tôi thấy thêm một vết sẹo mới, như thể linh hồn ấy đang đòi công bằng.");
            addStoryItem("Thầy Giáo Không Mặt", "Là sinh viên Đại học Công nghiệp TPHCM, tôi thường học khuya ở thư viện. Một đêm mưa lớn, tôi nghe tiếng gõ cửa phòng học cũ. Mở cửa, một bóng dáng thầy giáo mặc áo blouse trắng đứng đó, nhưng khuôn mặt ông ấy... không có. Chỉ là một khoảng tối đen kịt. Giọng khàn khàn vang lên: 'Em quên trả bài kiểm tra rồi.' Tôi đóng sầm cửa, nhưng sáng hôm sau, bài kiểm tra của tôi bị xé nát, dính đầy chất lỏng đỏ. Đồn rằng thầy ấy đã chết trong phòng thí nghiệm, và giờ ông ta lang thang tìm học sinh 'nợ' ông.");
            addStoryItem("Ghế Ngồi Bị Nguyền", "Tôi là cựu học sinh THPT Võ Thị Sáu. Trong lớp học cũ kỹ, có một chiếc ghế luôn lạnh buốt dù mùa hè. Tôi từng ngồi thử vì tò mò, và ngay lập tức, tai tôi ù đi với tiếng thì thầm: 'Đừng ngồi, nó sẽ giữ mày mãi mãi.' Đêm đó, tôi mơ thấy mình bị trói vào ghế, xung quanh là những linh hồn học sinh mất tích, cười khúc khích. Sáng dậy, chân tôi tê liệt suốt một ngày.");
            addStoryItem("Tiếng Gõ Bút Đêm Khuya", "Tại Đại học Công nghiệp, tôi ở ký túc xá gần phòng học cũ. Mỗi đêm khuya, tôi nghe tiếng gõ bút đều đặn từ phòng bên. Đi kiểm tra, phòng trống không, nhưng tiếng gõ vẫn tiếp tục. Một lần, tôi thấy bóng dáng một sinh viên cúi đầu viết bài, nhưng khi hắn ngẩng lên, khuôn mặt chỉ là da thịt rữa nát. 'Giúp tao làm bài đi,' hắn thì thầm. Từ đó, mỗi khi tôi viết bài, tay tôi tự động viết những công thức lạ lùng, dẫn đến tai nạn.");

        } else if (topicName.equals("Hành Lang Bóng Đêm")) {
            addStoryItem("Chiếc Khăn Đỏ", "Tôi là bảo vệ trường THPT Võ Thị Sáu ở Bình Thạnh. Một đêm tuần tra hành lang tầng 3, tôi thấy một cô gái quàng khăn đỏ đứng cuối hành lang. Cô ta quay lại, khuôn mặt trắng bệch, mắt chảy máu: 'Trả khăn cho tôi... nó bị nhuộm máu của tao.' Tôi chạy mất, nhưng sáng hôm sau, khăn đỏ ấy nằm trên bàn làm việc của tôi, ướt sũng. Đồn rằng cô gái ấy bị giết ở đây, và giờ cô ta lang thang đòi lại món đồ cuối cùng.");
            addStoryItem("Tiếng Thét Giữa Giờ", "Là sinh viên Đại học Công nghiệp, tôi thường ngủ trưa ở hành lang vắng. Một hôm, tiếng thét rùng rợn vang lên từ cuối hành lang cấm. Tôi và bạn đi kiểm tra, chỉ thấy một vũng nước đen đặc, mùi tanh nồng. Đụng vào, tay tôi bỏng rát, và đêm đó, tôi mơ thấy một linh hồn bị chôn dưới sàn, thét lên đòi đào lên. Sáng dậy, sàn hành lang nứt toác, lộ ra xương người.");
            addStoryItem("Cầu Thang Lên Trời", "Tôi từng học ở THPT Võ Thị Sáu. Cầu thang thoát hiểm chỉ 5 tầng, nhưng một đêm mất điện, tôi bước nhầm lên bậc thứ 6. Không khí lạnh buốt, tiếng bước chân chạy xuống từ trên cao. Tôi chạy lên theo, nhưng càng lên, cầu thang dài vô tận, và tiếng thì thầm: 'Lên đây với tao... mãi mãi.' Tôi tỉnh dậy ở tầng 1, nhưng từ đó, mỗi khi đi cầu thang, tôi thấy bóng dáng mình từ tương lai, rơi xuống vực.");
            addStoryItem("Bóng Đen Cuối Hành Lang", "Tại Đại học Công nghiệp, tôi thấy bóng đen lướt qua hành lang mỗi nửa đêm. Một lần theo dõi, bóng đen dừng lại, quay đầu: khuôn mặt là của tôi, nhưng già nua và méo mó. 'Mày sẽ thay tao,' nó nói. Từ đó, tôi cảm thấy cơ thể yếu dần, như thể linh hồn ấy đang hút sức sống.");
            addStoryItem("Tiếng Khóc Trẻ Em", "Là giáo viên THPT Võ Thị Sáu, tôi nghe tiếng khóc trẻ em từ hành lang cũ. Đi tìm, chỉ thấy một con búp bê cũ kỹ, mắt nó chớp. Nhặt lên, tôi mơ thấy một đứa trẻ bị bỏ rơi ở đây, chết đói. Sáng dậy, búp bê nằm bên giường, và tay tôi có vết cắn nhỏ.");

        } else if (topicName.equals("Phòng Thí Nghiệm Cũ")) {
            addStoryItem("Con Mắt Trong Lọ", "Tôi là kỹ thuật viên Đại học Công nghiệp. Trong phòng thí nghiệm cũ, tôi thấy lọ chất lỏng xanh với con mắt bên trong chớp nhẹ, nhìn tôi. Đụng vào, con mắt xoay theo tay tôi. Đêm đó, tôi mơ thấy con mắt ấy là của một sinh viên chết trong thí nghiệm thất bại, và nó thì thầm: 'Nhìn tao đi... mãi mãi.' Sáng dậy, mắt tôi mờ dần, như bị hút vào lọ.");
            addStoryItem("Người Thí Nghiệm Cuối", "Là cựu sinh viên THPT Võ Thị Sáu, tôi từng lẻn vào phòng thí nghiệm cũ. Thấy bóng dáng cô phụ tá di chuyển, nhưng cô ấy đã chết từ lâu. Cô ta quay lại, da thịt thối rữa: 'Thí nghiệm chưa xong... mày là mẫu tiếp theo.' Tôi chạy thoát, nhưng từ đó, cơ thể tôi thay đổi lạ lùng, như bị biến đổi gene.");
            addStoryItem("Hóa Chất Ăn Mòn Linh Hồn", "Tại Đại học Công nghiệp, tôi vô tình đổ hóa chất cũ lên tay. Không đau, nhưng đêm đó, da tôi bong tróc, lộ ra xương. Trong gương, tôi thấy linh hồn mình bị ăn mòn, thì thầm: 'Nó sẽ lấy hết... từ trong ra ngoài.' Đồn rằng hóa chất ấy bị nguyền vì tai nạn chết người.");
            addStoryItem("Tiếng Nổ Từ Quá Khứ", "Tôi là bảo vệ THPT Võ Thị Sáu. Mỗi đêm, tiếng nổ vang từ phòng thí nghiệm bỏ hoang. Vào kiểm tra, thấy cảnh tái hiện tai nạn cũ: một học sinh bị nổ tung. Bóng dáng ấy lao về phía tôi: 'Giúp tao... đau lắm.' Sáng dậy, cơ thể tôi đầy vết bỏng.");
            addStoryItem("Bình Thủy Tinh Sống", "Ở Đại học Công nghiệp, bình thủy tinh cũ rung nhẹ khi tôi chạm. Bên trong, chất lỏng cuộn trào như có sự sống. Đêm đó, tôi mơ thấy bình ấy nuốt chửng linh hồn, và sáng dậy, tôi thấy bình nằm bên giường, đầy hơn trước.");
        }
    }

    /**
     * Hàm này tạo ra 1 mục truyện (từ file item_story.xml) và thêm vào "thùng chứa"
     */
    private void addStoryItem(String title, String content) {
        // 1. Lấy layout mẫu
        View storyItemView = inflater.inflate(R.layout.item_story, storyListContainer, false);

        // 2. Tìm TextView bên trong
        TextView tvTitle = storyItemView.findViewById(R.id.tv_story_title_item);
        tvTitle.setText(title);

        // 3. Gán sự kiện click
        storyItemView.setOnClickListener(v -> {
            if (getActivity() != null) {
                // Giả sử MainActivity có phương thức gotoM003Screen
                // Lưu ý: Cần đảm bảo MainActivity có phương thức này và xử lý content hợp lý.
                ((MainActivity) getActivity()).gotoM003Screen(topicName, title, content);
            }
        });

        // 4. Thêm vào "thùng chứa"
        storyListContainer.addView(storyItemView);

        // 5. Thêm 1 đường kẻ phân cách (cho đẹp) - Dùng màu tối hơn cho kinh dị
        View divider = new View(getContext());
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1 // Rộng match_parent, cao 1dp
        ));
        // Sử dụng màu tối thay vì xám nhạt (0xFFE0E0E0)
        // Nếu bạn đã có màu darkMid/darkLight trong colors.xml, hãy dùng nó. Ví dụ:
        // divider.setBackgroundColor(getResources().getColor(R.color.darkMid));
        divider.setBackgroundColor(0xFF424242); // Màu xám đen
        storyListContainer.addView(divider);
    }
}