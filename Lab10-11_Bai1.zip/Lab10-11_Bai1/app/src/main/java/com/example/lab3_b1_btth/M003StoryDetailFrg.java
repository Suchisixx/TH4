package com.example.lab3_b1_btth;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class M003StoryDetailFrg extends Fragment implements View.OnClickListener {

    private static final String KEY_TOPIC_NAME = "TOPIC_NAME";
    private static final String KEY_STORY_TITLE = "STORY_TITLE";
    private static final String KEY_STORY_CONTENT = "STORY_CONTENT";

    // --- Factory method để tạo Fragment và truyền dữ liệu ---
    public static M003StoryDetailFrg newInstance(String topicName, String storyTitle, String storyContent) {
        M003StoryDetailFrg fragment = new M003StoryDetailFrg();
        Bundle args = new Bundle();
        args.putString(KEY_TOPIC_NAME, topicName);
        args.putString(KEY_STORY_TITLE, storyTitle);
        args.putString(KEY_STORY_CONTENT, storyContent);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // SỬA: Phải dùng layout dành cho chi tiết truyện
        View view = inflater.inflate(R.layout.m003_frg_story_detail, container, false);

        if (getArguments() != null) {
            String topicName = getArguments().getString(KEY_TOPIC_NAME);
            String storyTitle = getArguments().getString(KEY_STORY_TITLE);
            String storyContent = getArguments().getString(KEY_STORY_CONTENT);

            // --- Ánh xạ View ---
            // Action Bar Views
            ImageView ivBack = view.findViewById(R.id.iv_back_m003); // Nút Back
            TextView tvTopicName = view.findViewById(R.id.tv_topic_name_m003); // Tên chủ đề trên Action Bar

            // Detail Views
            TextView tvStoryTitle = view.findViewById(R.id.tv_story_title_m003); // Tiêu đề truyện
            TextView tvStoryContent = view.findViewById(R.id.tv_story_content_m003); // Nội dung truyện

            // --- Gán dữ liệu ---
            tvTopicName.setText(topicName);
            tvStoryTitle.setText(storyTitle);
            tvStoryContent.setText(storyContent);

            // --- Bắt sự kiện click ---
            ivBack.setOnClickListener(this);
        }

        return view;
    }

    @Override
    public void onClick(View v) {
        if (getActivity() == null) return;

        int id = v.getId();
        if (id == R.id.iv_back_m003) {
            // Quay lại màn hình trước đó (M002)
            getActivity().getOnBackPressedDispatcher().onBackPressed();
        }
    }
}